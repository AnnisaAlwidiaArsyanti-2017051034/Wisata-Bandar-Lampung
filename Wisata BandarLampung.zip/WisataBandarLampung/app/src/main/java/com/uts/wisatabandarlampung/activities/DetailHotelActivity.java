package com.uts.wisatabandarlampung.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.uts.wisatabandarlampung.R;

public class DetailHotelActivity extends AppCompatActivity {

   @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_detail_hotel);
   }
}