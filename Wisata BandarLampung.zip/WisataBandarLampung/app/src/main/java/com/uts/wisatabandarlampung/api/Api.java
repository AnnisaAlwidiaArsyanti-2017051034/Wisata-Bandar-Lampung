package com.uts.wisatabandarlampung.api;


public class Api {

    public static String Hotel = "";
    public static String Kuliner = "";
    public static String DetailKuliner = "";
    public static String TempatIbadah = "";
    public static String Wisata = "";
    public static String DetailWisata = "";

}
